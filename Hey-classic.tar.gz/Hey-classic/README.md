# Hey icons by adhe

Inspired on Linebit icons for android

### Installation

Download, extract and place the icons folders in

```bash
~/.local/share/icons/
```

This package is a set of icons (not complte), if you prefer you just have to modify the following line in the file *index.theme* to combine with your favorite icon set.

```bash
#Inherits=Papirus,OieIcons,breeze,Yaru,Numix-Circle
Inherits=myFavoriteTheme
```

### Coffe

Thanks for all the support.

If you liked the icons please Pling ![plinghover](https://www.opendesktop.org/images/system/pling-btn-hover.png "") the project or/and rate  (above in the + symbol) or/and make a donation [here](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8L3MF9FCT5ZQY&source=url)

<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8L3MF9FCT5ZQY&source=url" rel="oxy">![Foo](https://git.opendesktop.org/adhe/oieoxy/raw/master/images/donate.png "")</a>


Have fun and use Linux ;)

